const global = {
    owner: [6890896358], // ganti jadi id mu
    botToken: "https://t.me/official_kango2/494", //isi make token bot mu
}

module.exports = global;